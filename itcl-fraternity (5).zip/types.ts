
export type UserRole = 'engineer' | 'admin';
export type UserStatus = 'active' | 'pending';

export type TicketStatus = 'Open' | 'In Progress' | 'Resolved' | 'Cancelled';
export type Priority = 'Low' | 'Medium' | 'High' | 'Critical';

export interface Customer {
  name: string;
  phone: string;
  address: string;
}

export interface Ticket {
  id: number;
  customer: Customer;
  issue: string;
  priority: Priority;
  status: TicketStatus;
  assignedTo: number | null; // User ID
  createdBy: number; // User ID
  notes?: string;
  createdAt: string; // ISO String
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  isOnline: boolean;
  location?: { lat: number; lng: number };
}

export interface EmergencyAlert {
    id: number;
    engineerId: number;
    timestamp: string; // ISO String
    note: string;
    location: { lat: number; lng: number };
    status: 'active' | 'resolved';
}