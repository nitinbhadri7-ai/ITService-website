import React, { useState } from 'react';
import Login from './components/Login';
// Removed incorrect comment 'Corrected import path for AdminDashboard' which was causing a TypeScript error.
import AdminDashboard from './components/AdminDashboard'; 
import EngineerDashboard from './components/EngineerDashboard';
import { User, Ticket, EmergencyAlert, UserRole, UserStatus, Priority, TicketStatus } from './types';
import EngineerSignUp from './components/EngineerSignUp';

// Mock Data
const initialUsers: User[] = [
  { id: 1, name: 'Admin User', email: 'admin@itcl.com', role: 'admin', status: 'active', isOnline: true },
  { id: 2, name: 'Nitin Bhadri', email: 'nitin@itcl.com', role: 'engineer', status: 'active', isOnline: true, location: { lat: 34.0522, lng: -118.2437 } },
  { id: 3, name: 'Jane Doe', email: 'jane@itcl.com', role: 'engineer', status: 'active', isOnline: false, location: { lat: 40.7128, lng: -74.0060 } },
  { id: 4, name: 'John Smith', email: 'john@itcl.com', role: 'engineer', status: 'pending', isOnline: false, location: { lat: 41.8781, lng: -87.6298 } },
];

const initialTickets: Ticket[] = [
  {
    id: 101,
    customer: { name: 'Alice Johnson', phone: '555-0101', address: '123 Maple St' },
    issue: 'Fix Wifi connection',
    priority: 'High',
    status: 'In Progress',
    assignedTo: 2,
    createdBy: 1,
    createdAt: '2024-07-29T10:00:00Z',
    notes: 'Customer reports intermittent connection issues.'
  },
  {
    id: 102,
    customer: { name: 'Bob Williams', phone: '555-0102', address: '456 Oak Ave' },
    issue: 'Install new server rack',
    priority: 'Medium',
    status: 'Open',
    assignedTo: null,
    createdBy: 1,
    createdAt: '2024-07-29T11:30:00Z',
  },
    {
    id: 103,
    customer: { name: 'Charlie Brown', phone: '555-0103', address: '789 Pine Ln' },
    issue: 'Printer not responding',
    priority: 'Low',
    status: 'Resolved',
    assignedTo: 3,
    createdBy: 1,
    createdAt: '2024-07-28T14:00:00Z',
    notes: 'Restarted the print spooler service.'
  },
  {
    id: 104,
    customer: { name: 'Diana Prince', phone: '555-0104', address: '1 Wonder Way' },
    issue: 'Software update failed',
    priority: 'Critical',
    status: 'In Progress',
    assignedTo: 2,
    createdBy: 1,
    createdAt: '2024-07-30T09:00:00Z',
  },
];

const initialAlerts: EmergencyAlert[] = [
    {
        id: 1,
        engineerId: 3,
        timestamp: '2024-07-30T11:00:00Z',
        note: 'Stuck in elevator at client site. Need assistance.',
        location: { lat: 34.0522, lng: -118.2437 },
        status: 'active',
    },
    {
        id: 2,
        engineerId: 2,
        timestamp: '2024-07-28T16:45:00Z',
        note: 'Vehicle breakdown on the way to a critical call.',
        location: { lat: 34.0522, lng: -118.2437 },
        status: 'resolved',
    }
];


const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [tickets, setTickets] = useState<Ticket[]>(initialTickets);
  const [alerts, setAlerts] = useState<EmergencyAlert[]>(initialAlerts);
  const [showSignUp, setShowSignUp] = useState(false); // New state for showing sign-up

  const handleLogin = (user: User, loginRole: UserRole) => {
    // Strict role check
    if (user.role !== loginRole) {
      // This case should ideally be caught by Login.tsx, but good for redundancy
      console.error(`User ${user.email} is a ${user.role} but attempted to log in as ${loginRole}`);
      alert(`Access Denied: You are a ${user.role}, please use the ${user.role} panel.`);
      return;
    }
    setCurrentUser(user);
    setShowSignUp(false); // Hide sign-up form after login
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const handleUsersUpdate = (updatedUsers: User[]) => {
    console.log('App.tsx: handleUsersUpdate called with:', updatedUsers);
    setUsers(updatedUsers);
  };

  const handleTicketsUpdate = (updatedTickets: Ticket[]) => {
    setTickets(updatedTickets);
  };

  const handleUpdateTicket = (updatedTicket: Ticket) => {
    setTickets(prevTickets =>
      prevTickets.map(ticket => (ticket.id === updatedTicket.id ? updatedTicket : ticket))
    );
  };

  const handleAlertsUpdate = (updatedAlerts: EmergencyAlert[]) => {
    setAlerts(updatedAlerts);
  };
  
  const handleUserUpdate = (updatedUser: User) => {
    setUsers(prevUsers =>
      prevUsers.map(user => (user.id === updatedUser.id ? updatedUser : user))
    );
    if (currentUser && currentUser.id === updatedUser.id) {
        setCurrentUser(updatedUser);
    }
  };

  const handleEngineerSignUp = (name: string, email: string) => {
    const newEngineer: User = {
      id: Math.max(0, ...users.map(u => u.id)) + 1,
      name,
      email,
      role: 'engineer',
      status: 'pending', // New accounts start as pending
      isOnline: false,
      location: undefined, // No location initially
    };
    setUsers(prevUsers => [...prevUsers, newEngineer]);
    alert('Sign up successful! Your account is pending admin approval.');
    setShowSignUp(false); // Go back to login screen
  };

  const handleCreateEmergencyAlert = (engineerId: number, note: string, location: { lat: number; lng: number }) => {
    const newAlert: EmergencyAlert = {
      id: Math.max(0, ...alerts.map(a => a.id)) + 1,
      engineerId,
      timestamp: new Date().toISOString(),
      note,
      location,
      status: 'active',
    };
    setAlerts(prevAlerts => [...prevAlerts, newAlert]);
  };

  const handleEngineerCreateTicket = (customerName: string, customerPhone: string, customerAddress: string, issue: string, priority: Priority, notes?: string) => {
    if (!currentUser || currentUser.role !== 'engineer') return; // Only engineers can create engineer-assigned tickets
    const newTicket: Ticket = {
      id: Math.max(0, ...tickets.map(t => t.id)) + 1,
      customer: { name: customerName, phone: customerPhone, address: customerAddress },
      issue,
      priority,
      status: 'In Progress', // Automatically in progress when engineer creates and assigns to self
      assignedTo: currentUser.id,
      createdBy: currentUser.id,
      createdAt: new Date().toISOString(),
      notes,
    };
    setTickets(prevTickets => [newTicket, ...prevTickets]);
  };

  const handleAdminCreateTicket = (
    customerName: string,
    customerPhone: string,
    customerAddress: string,
    issue: string,
    priority: Priority,
    status: TicketStatus,
    assignedToId: number | null,
    notes?: string
  ) => {
    if (!currentUser || currentUser.role !== 'admin') return; // Only admins can use this function
    const newTicket: Ticket = {
      id: Math.max(0, ...tickets.map(t => t.id)) + 1,
      customer: { name: customerName, phone: customerPhone, address: customerAddress },
      issue,
      priority,
      status,
      assignedTo: assignedToId,
      createdBy: currentUser.id, // Admin is the creator
      createdAt: new Date().toISOString(),
      notes,
    };
    setTickets(prevTickets => [newTicket, ...prevTickets]);
  };


  if (!currentUser) {
    if (showSignUp) {
        return <EngineerSignUp onSignUp={handleEngineerSignUp} onCancel={() => setShowSignUp(false)} users={users} />;
    }
    return <Login onLogin={handleLogin} users={users} onShowSignUp={() => setShowSignUp(true)} />;
  }

  if (currentUser.role === 'admin') {
    return (
      <AdminDashboard
        currentUser={currentUser}
        tickets={tickets}
        users={users}
        alerts={alerts}
        onLogout={handleLogout}
        onUsersUpdate={handleUsersUpdate}
        onTicketsUpdate={handleTicketsUpdate}
        onUpdateTicket={handleUpdateTicket} // Pass the new handler
        onAlertsUpdate={handleAlertsUpdate}
        onCreateTicket={handleAdminCreateTicket} // Pass the new handler
      />
    );
  }

  if (currentUser.role === 'engineer') {
    const engineerTickets = tickets.filter(
      (ticket) => ticket.assignedTo === currentUser.id
    );
    return (
      <EngineerDashboard
        currentUser={currentUser}
        tickets={engineerTickets}
        myAlerts={alerts.filter(a => a.engineerId === currentUser.id)}
        onLogout={handleLogout}
        onUpdateUser={handleUserUpdate}
        onCreateEmergencyAlert={handleCreateEmergencyAlert}
        onCreateTicket={handleEngineerCreateTicket}
        onAlertsUpdate={handleAlertsUpdate} // Needed for resolving alerts
        onUpdateTicket={handleUpdateTicket} // Pass onUpdateTicket to EngineerDashboard
      />
    );
  }

  return null; // Should not happen
};

export default App;