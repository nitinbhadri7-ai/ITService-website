import React, { useState } from 'react';
import { UserIcon } from './icons/UserIcon';
import { BellIcon } from './icons/BellIcon';
import { ClipboardListIcon } from './icons/ClipboardListIcon';
import { InfinityIcon } from './icons/InfinityIcon';
import { UsersIcon } from './icons/UsersIcon';
import { AlertTriangleIcon } from './icons/AlertTriangleIcon';
import { CheckIcon } from './icons/CheckIcon';
import { XIcon } from './icons/XIcon';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';
import { EditIcon } from './icons/EditIcon';
import { ArchiveIcon } from './icons/ArchiveIcon'; // New icon import
import { MapIcon } from './icons/MapIcon'; // New icon import for map

import { User, Ticket, EmergencyAlert, UserStatus, TicketStatus, Priority } from '../types';
import EngineerMapView from './EngineerMapView'; // New component import

interface AdminDashboardProps {
  onLogout: () => void;
  tickets: Ticket[];
  users: User[];
  alerts: EmergencyAlert[];
  currentUser: User;
  onUsersUpdate: (users: User[]) => void;
  onTicketsUpdate: (tickets: Ticket[]) => void;
  onUpdateTicket: (updatedTicket: Ticket) => void; // New prop for updating single ticket
  onAlertsUpdate: (alerts: EmergencyAlert[]) => void;
  onCreateTicket: (
    customerName: string,
    customerPhone: string,
    customerAddress: string,
    issue: string,
    priority: Priority,
    status: TicketStatus,
    assignedToId: number | null,
    notes?: string
  ) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onLogout,
  tickets,
  users,
  alerts,
  currentUser,
  onUsersUpdate,
  onTicketsUpdate,
  onUpdateTicket, // Destructure new prop
  onAlertsUpdate,
  onCreateTicket,
}) => {
  const [activeTab, setActiveTab] = useState<'tickets' | 'engineers' | 'alerts' | 'completedTickets' | 'engineerMap'>('tickets');
  const [isUserDetailsModalOpen, setUserDetailsModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isTicketDetailsModalOpen, setTicketDetailsModalOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [isAlertDetailsModalOpen, setAlertDetailsModalOpen] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState<EmergencyAlert | null>(null);
  const [isCreateTicketModalOpen, setCreateTicketModalOpen] = useState(false);

  // New states for ticket editing
  const [isEditingTicket, setIsEditingTicket] = useState(false);
  const [editedStatus, setEditedStatus] = useState<TicketStatus | ''>('');
  const [editedAssignedToId, setEditedAssignedToId] = useState<number | null>(null);
  const [editedNotes, setEditedNotes] = useState<string>('');


  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open':
        return 'bg-red-100 text-red-800';
      case 'In Progress':
        return 'bg-yellow-100 text-yellow-800';
      case 'Resolved':
        return 'bg-green-100 text-green-800';
      case 'Cancelled':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getUserStatusColor = (status: UserStatus) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getAlertStatusColor = (status: 'active' | 'resolved') => {
    switch (status) {
      case 'active':
        return 'bg-red-100 text-red-800';
      case 'resolved':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Fix: Explicitly cast 'active' to UserStatus to satisfy TypeScript's strict type checking.
  const handleActivateEngineer = (userId: number) => {
    const updatedUsers = users.map((user) =>
      user.id === userId ? { ...user, status: 'active' as UserStatus } : user
    );
    onUsersUpdate(updatedUsers);
    if (selectedUser?.id === userId) {
        setSelectedUser(prev => prev ? { ...prev, status: 'active' as UserStatus } : null);
    }
    alert('Engineer activated!');
  };

  const handleRejectEngineer = (userId: number) => {
    if (!window.confirm('Are you sure you want to reject this engineer? This action cannot be undone.')) {
        return;
    }
    const updatedUsers = users.filter((user) => user.id !== userId);
    onUsersUpdate(updatedUsers);
    if (selectedUser?.id === userId) {
        setUserDetailsModalOpen(false);
        setSelectedUser(null);
    }
    alert('Engineer rejected and removed.');
  };

  const handleDeleteEngineer = (userId: number) => {
    console.log(`Attempting to delete engineer with ID: ${userId}`);
    const confirmed = window.confirm('Are you sure you want to delete this engineer? This action cannot be undone.');
    console.log(`User confirmation result for ID ${userId}: ${confirmed}`);

    if (!confirmed) {
        console.log('Engineer deletion cancelled by user.');
        return;
    }

    console.log(`User confirmed deletion for engineer with ID: ${userId}`);
    const updatedUsers = users.filter((user) => user.id !== userId);
    console.log('Updated users array after filter (before onUsersUpdate):', updatedUsers);
    onUsersUpdate(updatedUsers);
    if (selectedUser?.id === userId) {
        setUserDetailsModalOpen(false);
        setSelectedUser(null);
    }
    alert('Engineer account deleted.');
    console.log('Engineer account deletion successful for ID:', userId);
  };

  // Fix: Explicitly cast 'resolved' to EmergencyAlert['status'] to satisfy TypeScript's strict type checking.
  const handleResolveAlert = (alertId: number) => {
    const updatedAlerts = alerts.map((alert) =>
      alert.id === alertId ? { ...alert, status: 'resolved' as EmergencyAlert['status'] } : alert
    );
    onAlertsUpdate(updatedAlerts);
    if (selectedAlert?.id === alertId) {
        setSelectedAlert(prev => prev ? { ...prev, status: 'resolved' as EmergencyAlert['status'] } : null);
    }
    alert('Emergency alert marked as resolved.');
  };

  const handleCreateNewTicket = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const customerName = formData.get('customerName') as string;
    const customerPhone = formData.get('customerPhone') as string;
    const customerAddress = formData.get('customerAddress') as string;
    const issue = formData.get('issue') as string;
    const priority = formData.get('priority') as Priority;
    const status = formData.get('status') as TicketStatus;
    const assignedTo = formData.get('assignedTo') as string;
    const notes = formData.get('notes') as string;

    const assignedToId = assignedTo === 'Unassigned' ? null : parseInt(assignedTo);

    onCreateTicket(customerName, customerPhone, customerAddress, issue, priority, status, assignedToId, notes);
    setCreateTicketModalOpen(false);
    alert('New ticket created successfully!');
  };

  const handleOpenTicketDetails = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setEditedStatus(ticket.status);
    setEditedAssignedToId(ticket.assignedTo);
    setEditedNotes(ticket.notes || ''); // Initialize editedNotes
    setIsEditingTicket(false); // Start in view mode
    setTicketDetailsModalOpen(true);
  };

  const handleSaveTicketChanges = () => {
    if (selectedTicket && editedStatus) {
      const updatedTicket: Ticket = {
        ...selectedTicket,
        status: editedStatus,
        assignedTo: editedAssignedToId,
        notes: editedNotes.trim() === '' ? undefined : editedNotes, // Save notes, or undefined if empty
      };
      onUpdateTicket(updatedTicket); // Use the new prop
      setSelectedTicket(updatedTicket); // Update selectedTicket for display
      setIsEditingTicket(false); // Exit edit mode
      alert('Ticket updated successfully!');
    }
  };

  const handleCancelTicketEdit = () => {
    // Revert changes and exit edit mode
    if (selectedTicket) {
      setEditedStatus(selectedTicket.status);
      setEditedAssignedToId(selectedTicket.assignedTo);
      setEditedNotes(selectedTicket.notes || ''); // Revert notes
    }
    setIsEditingTicket(false);
  };

  // Filter engineers who are active AND online for assignment purposes
  const assignableEngineers = users.filter(
    user => user.role === 'engineer' && user.status === 'active' && user.isOnline
  );

  // Filter engineers who are active and have a location for map display
  const engineersWithLocation = users.filter(
    user => user.role === 'engineer' && user.status === 'active' && user.isOnline && user.location
  );

  const TicketsView = () => (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b flex justify-between items-center">
        <h3 className="text-lg font-semibold">Open & In Progress Tickets</h3>
        <button onClick={() => setCreateTicketModalOpen(true)} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 flex items-center">
          <PlusIcon className="w-4 h-4 mr-2" /> Create New Ticket
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ticket ID</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Issue</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Assigned To</th>
              <th scope="col" className="relative px-6 py-3">
                <span className="sr-only">View</span>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {tickets.filter(ticket => ticket.status !== 'Resolved' && ticket.status !== 'Cancelled').map((ticket) => (
              <tr key={ticket.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{ticket.id}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{ticket.customer.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-sm">{ticket.issue}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{ticket.priority}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(ticket.status)}`}>
                    {ticket.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {ticket.assignedTo ? users.find(u => u.id === ticket.assignedTo)?.name : 'Unassigned'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button onClick={() => handleOpenTicketDetails(ticket)} className="text-indigo-600 hover:text-indigo-900">View</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const EngineersView = () => (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b">
        <h3 className="text-lg font-semibold">Engineer Accounts</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Engineer ID</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Engineer Name</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Online</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th> {/* New column header */}
              <th scope="col" className="relative px-6 py-3">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {users.filter(user => user.role === 'engineer').map((engineer) => (
              <tr key={engineer.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{engineer.id}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{engineer.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{engineer.email}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getUserStatusColor(engineer.status)}`}>
                    {engineer.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{engineer.isOnline ? 'Yes' : 'No'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {engineer.location ? `Lat: ${engineer.location.lat.toFixed(2)}, Lng: ${engineer.location.lng.toFixed(2)}` : 'N/A'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  {engineer.status === 'pending' ? (
                    <>
                      <button
                        onClick={() => handleActivateEngineer(engineer.id)}
                        className="text-green-600 hover:text-green-900 mr-3"
                      >
                        <CheckIcon className="w-5 h-5 inline-block" /> Approve
                      </button>
                      <button
                        onClick={() => handleRejectEngineer(engineer.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <XIcon className="w-5 h-5 inline-block" /> Reject
                      </button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => { setSelectedUser(engineer); setUserDetailsModalOpen(true); }} className="text-indigo-600 hover:text-indigo-900 mr-3">View</button>
                      <button onClick={() => handleDeleteEngineer(engineer.id)} className="text-red-600 hover:text-red-900">
                        <TrashIcon className="w-5 h-5 inline-block" /> Delete
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const AlertsView = () => (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b">
        <h3 className="text-lg font-semibold">Emergency Alerts</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Alert ID</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Engineer</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th scope="col" className="relative px-6 py-3">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {alerts.map((alert) => (
              <tr key={alert.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{alert.id}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{users.find(u => u.id === alert.engineerId)?.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(alert.timestamp).toLocaleString()}</td>
                <td className="px-6 py-4 text-sm text-gray-500 truncate max-w-md">{alert.note}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getAlertStatusColor(alert.status)}`}>
                    {alert.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button onClick={() => { setSelectedAlert(alert); setAlertDetailsModalOpen(true); }} className="text-indigo-600 hover:text-indigo-900">View Details</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const CompletedTicketsView = () => (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b">
        <h3 className="text-lg font-semibold">Completed Tickets</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ticket ID</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Issue</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Assigned To</th>
              <th scope="col" className="relative px-6 py-3">
                <span className="sr-only">View</span>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {tickets.filter(ticket => ticket.status === 'Resolved' || ticket.status === 'Cancelled').map((ticket) => (
              <tr key={ticket.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{ticket.id}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{ticket.customer.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-sm">{ticket.issue}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{ticket.priority}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(ticket.status)}`}>
                    {ticket.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {ticket.assignedTo ? users.find(u => u.id === ticket.assignedTo)?.name : 'Unassigned'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button onClick={() => handleOpenTicketDetails(ticket)} className="text-indigo-600 hover:text-indigo-900">View</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-gray-800 text-white flex flex-col">
        <div className="flex items-center justify-center h-20 border-b border-gray-700">
          <InfinityIcon className="h-8 w-8 mr-2" />
          <h1 className="text-xl font-bold">ITCL Admin</h1>
        </div>
        <nav className="flex-1 px-4 py-6 space-y-2">
          <button
            onClick={() => setActiveTab('tickets')}
            className={`flex items-center w-full px-4 py-2 text-left rounded-md transition-colors ${activeTab === 'tickets' ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}
          >
            <ClipboardListIcon className="h-5 w-5 mr-3" />
            Tickets
          </button>
          <button
            onClick={() => setActiveTab('engineers')}
            className={`flex items-center w-full px-4 py-2 text-left rounded-md transition-colors ${activeTab === 'engineers' ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}
          >
            <UsersIcon className="h-5 w-5 mr-3" />
            Engineers
          </button>
          <button
            onClick={() => setActiveTab('alerts')}
            className={`flex items-center w-full px-4 py-2 text-left rounded-md transition-colors ${activeTab === 'alerts' ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}
          >
            <AlertTriangleIcon className="h-5 w-5 mr-3" />
            Alerts
          </button>
          <button
            onClick={() => setActiveTab('completedTickets')}
            className={`flex items-center w-full px-4 py-2 text-left rounded-md transition-colors ${activeTab === 'completedTickets' ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}
          >
            <ArchiveIcon className="h-5 w-5 mr-3" />
            Completed Tickets
          </button>
          <button
            onClick={() => setActiveTab('engineerMap')}
            className={`flex items-center w-full px-4 py-2 text-left rounded-md transition-colors ${activeTab === 'engineerMap' ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}
          >
            <MapIcon className="h-5 w-5 mr-3" />
            Engineer Map
          </button>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="flex justify-between items-center p-6 bg-white border-b">
          <h2 className="text-2xl font-semibold text-gray-800">
            {activeTab === 'tickets' ? 'Open & In Progress Tickets' :
             activeTab === 'engineers' ? 'Manage Engineers' :
             activeTab === 'alerts' ? 'Emergency Alerts' :
             activeTab === 'completedTickets' ? 'Completed Tickets' :
             'Engineer Live Locations'}
          </h2>
          <div className="flex items-center space-x-4">
            <BellIcon className="h-6 w-6 text-gray-500" />
            <div className="flex items-center space-x-2">
              <UserIcon className="h-8 w-8 text-gray-500 rounded-full bg-gray-200 p-1" />
              <div>
                <div className="font-semibold">{currentUser.name}</div>
                <div className="text-sm text-gray-500 capitalize">{currentUser.role}</div>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Logout
            </button>
          </div>
        </header>

        {/* Content area */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
          {activeTab === 'tickets' && <TicketsView />}
          {activeTab === 'engineers' && <EngineersView />}
          {activeTab === 'alerts' && <AlertsView />}
          {activeTab === 'completedTickets' && <CompletedTicketsView />}
          {activeTab === 'engineerMap' && <EngineerMapView engineers={engineersWithLocation} />}
        </main>
      </div>

      {/* Engineer Details Modal */}
      {isUserDetailsModalOpen && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={() => setUserDetailsModalOpen(false)}>
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-4">Engineer Details - {selectedUser.name}</h3>
            <p><strong>ID:</strong> {selectedUser.id}</p>
            <p><strong>Email:</strong> {selectedUser.email}</p>
            <p><strong>Role:</strong> <span className="capitalize">{selectedUser.role}</span></p>
            <p><strong>Status:</strong> <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getUserStatusColor(selectedUser.status)}`}>{selectedUser.status}</span></p>
            <p><strong>Online:</strong> {selectedUser.isOnline ? 'Yes' : 'No'}</p>
            <p><strong>Location:</strong> {selectedUser.location ? `Lat: ${selectedUser.location.lat}, Lng: ${selectedUser.location.lng}` : 'N/A'}</p>

            {selectedUser.status === 'pending' && selectedUser.role === 'engineer' && (
              <div className="mt-6 flex justify-end space-x-2">
                <button
                  onClick={() => handleActivateEngineer(selectedUser.id)}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center"
                >
                    <CheckIcon className="w-4 h-4 mr-2"/> Activate
                </button>
                <button
                  onClick={() => handleRejectEngineer(selectedUser.id)}
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 flex items-center"
                >
                    <XIcon className="w-4 h-4 mr-2"/> Reject
                </button>
              </div>
            )}
            {selectedUser.status === 'active' && selectedUser.role === 'engineer' && (
              <div className="mt-6 flex justify-end space-x-2">
                <button
                  onClick={() => handleDeleteEngineer(selectedUser.id)}
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 flex items-center"
                >
                    <TrashIcon className="w-4 h-4 mr-2"/> Delete Engineer
                </button>
              </div>
            )}
            <div className="mt-6 flex justify-end">
              <button onClick={() => setUserDetailsModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* Ticket Details Modal */}
      {isTicketDetailsModalOpen && selectedTicket && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={() => setTicketDetailsModalOpen(false)}>
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-4">Ticket Details - #{selectedTicket.id}</h3>
            <p><strong>Issue:</strong> {selectedTicket.issue}</p>
            <p><strong>Priority:</strong> {selectedTicket.priority}</p>
            <p className="flex items-center">
              <strong>Status:</strong>
              {isEditingTicket ? (
                <select
                  value={editedStatus}
                  onChange={(e) => setEditedStatus(e.target.value as TicketStatus)}
                  className="ml-2 p-1 border rounded text-sm"
                >
                  <option value="Open">Open</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              ) : (
                <span className={`px-2 ml-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(selectedTicket.status)}`}>{selectedTicket.status}</span>
              )}
            </p>
            <p><strong>Customer:</strong> {selectedTicket.customer.name}</p>
            <p><strong>Customer Phone:</strong> {selectedTicket.customer.phone}</p>
            <p><strong>Customer Address:</strong> {selectedTicket.customer.address}</p>
            <p className="flex items-center">
              <strong>Assigned To:</strong>
              {isEditingTicket ? (
                <select
                  value={editedAssignedToId === null ? 'Unassigned' : editedAssignedToId}
                  onChange={(e) => setEditedAssignedToId(e.target.value === 'Unassigned' ? null : parseInt(e.target.value))}
                  className="ml-2 p-1 border rounded text-sm"
                >
                  <option value="Unassigned">Unassigned</option>
                  {assignableEngineers.map(engineer => ( // Use assignableEngineers here
                    <option key={engineer.id} value={engineer.id}>{engineer.name}</option>
                  ))}
                </select>
              ) : (
                <span className="ml-2">{selectedTicket.assignedTo ? users.find(u => u.id === selectedTicket.assignedTo)?.name : 'Unassigned'}</span>
              )}
            </p>
            <p><strong>Created By:</strong> {users.find(u => u.id === selectedTicket.createdBy)?.name}</p>
            <p><strong>Created At:</strong> {new Date(selectedTicket.createdAt).toLocaleString()}</p>
            <p>
              <strong>Notes:</strong>
              {isEditingTicket ? (
                <textarea
                  value={editedNotes}
                  onChange={(e) => setEditedNotes(e.target.value)}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                  rows={3}
                  placeholder="Add notes for this ticket"
                ></textarea>
              ) : (
                <span className="ml-2 block">{selectedTicket.notes || 'N/A'}</span>
              )}
            </p>

            <div className="mt-6 flex justify-end space-x-2">
              {isEditingTicket ? (
                <>
                  <button onClick={handleCancelTicketEdit} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                  <button onClick={handleSaveTicketChanges} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center">
                      <CheckIcon className="w-4 h-4 mr-2"/> Save Changes
                  </button>
                </>
              ) : (
                <>
                  <button onClick={() => setIsEditingTicket(true)} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center">
                      <EditIcon className="w-4 h-4 mr-2"/> Edit
                  </button>
                  <button onClick={() => setTicketDetailsModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Close</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Alert Details Modal */}
      {isAlertDetailsModalOpen && selectedAlert && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={() => setAlertDetailsModalOpen(false)}>
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-4 text-red-600">Emergency Alert Details - #{selectedAlert.id}</h3>
            <p><strong>Engineer:</strong> {users.find(u => u.id === selectedAlert.engineerId)?.name}</p>
            <p><strong>Time:</strong> {new Date(selectedAlert.timestamp).toLocaleString()}</p>
            <p><strong>Note:</strong> {selectedAlert.note}</p>
            <p><strong>Location:</strong> Lat {selectedAlert.location.lat}, Lng {selectedAlert.location.lng}</p>
            <p><strong>Status:</strong> <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getAlertStatusColor(selectedAlert.status)}`}>{selectedAlert.status}</span></p>

            {selectedAlert.status === 'active' && (
              <div className="mt-6 flex justify-end space-x-2">
                <button
                  onClick={() => handleResolveAlert(selectedAlert.id)}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center"
                >
                    <CheckIcon className="w-4 h-4 mr-2"/> Resolve Alert
                </button>
              </div>
            )}
            <div className="mt-6 flex justify-end">
              <button onClick={() => setAlertDetailsModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* Create New Ticket Modal (Admin) */}
      {isCreateTicketModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={() => setCreateTicketModalOpen(false)}>
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-4">Create New Ticket</h3>
            <form onSubmit={handleCreateNewTicket}>
              <div className="space-y-4">
                <input name="customerName" placeholder="Customer Name" required className="w-full p-2 border rounded"/>
                <input name="customerPhone" placeholder="Customer Phone" required className="w-full p-2 border rounded"/>
                <input name="customerAddress" placeholder="Customer Address" required className="w-full p-2 border rounded"/>
                <textarea name="issue" placeholder="Issue Description" required className="w-full p-2 border rounded"></textarea>
                
                <select name="priority" defaultValue="Medium" className="w-full p-2 border rounded">
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                  <option value="Critical">Critical</option>
                </select>

                <select name="status" defaultValue="Open" className="w-full p-2 border rounded">
                  <option value="Open">Open</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Cancelled">Cancelled</option>
                </select>

                <select name="assignedTo" defaultValue="Unassigned" className="w-full p-2 border rounded">
                  <option value="Unassigned">Unassigned</option>
                  {assignableEngineers.map(engineer => ( // Use assignableEngineers here
                    <option key={engineer.id} value={engineer.id}>{engineer.name}</option>
                  ))}
                </select>

                <textarea name="notes" placeholder="Notes (optional)" className="w-full p-2 border rounded"></textarea>
              </div>
              <div className="mt-6 flex justify-end space-x-4">
                <button type="button" onClick={() => setCreateTicketModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded">Create Ticket</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;