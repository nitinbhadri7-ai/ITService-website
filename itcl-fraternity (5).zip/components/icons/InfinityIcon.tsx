import React from 'react';

export const InfinityIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M16 3c3.314 0 6 2.686 6 6s-2.686 6-6 6h-6c-3.314 0-6-2.686-6-6s2.686-6 6-6h6ZM6 21c-3.314 0-6-2.686-6-6s2.686-6 6-6h6c3.314 0 6 2.686 6 6s-2.686 6-6 6h-6Z"/>
  </svg>
);