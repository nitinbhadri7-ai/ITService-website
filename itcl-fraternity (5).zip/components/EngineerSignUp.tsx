
import React, { useState } from 'react';
import { User } from '../types';
import { InfinityIcon } from './icons/InfinityIcon';
import { MailIcon } from './icons/MailIcon';
import { UserIcon } from './icons/UserIcon';
import { InfoIcon } from './icons/InfoIcon';

interface EngineerSignUpProps {
  onSignUp: (name: string, email: string) => void;
  onCancel: () => void;
  users: User[];
}

const EngineerSignUp: React.FC<EngineerSignUpProps> = ({ onSignUp, onCancel, users }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Basic validation
    if (!name.trim() || !email.trim()) {
      setError('Name and Email cannot be empty.');
      return;
    }

    // Check if email already exists
    if (users.some(user => user.email === email)) {
      setError('An account with this email already exists.');
      return;
    }

    onSignUp(name, email);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <div className="flex flex-col items-center">
            <div className="bg-gray-800 p-3 rounded-xl flex flex-col items-center">
                <InfinityIcon className="w-12 h-12 text-white"/>
                <h1 className="mt-2 text-xl font-bold text-white">ITCL</h1>
                <p className="text-sm font-light text-white">FRATERNITY</p>
            </div>
            <h2 className="mt-6 text-2xl font-bold text-center text-gray-900">
                Engineer Sign Up
            </h2>
            <p className="mt-2 text-base text-center text-gray-600">
                Create your engineer account
            </p>
        </div>

        <form className="space-y-6" onSubmit={handleSubmit}>
          <div>
            <label htmlFor="name" className="text-sm font-medium text-gray-700 sr-only">
              Full Name
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <UserIcon className="w-5 h-5 text-gray-400" />
              </span>
              <input
                id="name"
                name="name"
                type="text"
                autoComplete="name"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="block w-full py-3 pl-10 pr-3 border border-gray-300 rounded-md shadow-sm appearance-none placeholder:text-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                placeholder="Full Name"
              />
            </div>
          </div>

          <div>
            <label htmlFor="email" className="text-sm font-medium text-gray-700 sr-only">
              Email address
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <MailIcon className="w-5 h-5 text-gray-400" />
              </span>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full py-3 pl-10 pr-3 border border-gray-300 rounded-md shadow-sm appearance-none placeholder:text-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                placeholder="Email"
              />
            </div>
          </div>

          {error && (
            <div className="flex items-start p-3 text-sm text-red-700 bg-red-100 rounded-md">
              <InfoIcon className="w-5 h-5 mr-2 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <button
              type="submit"
              className="flex justify-center w-full px-4 py-3 text-sm font-medium text-white bg-green-600 rounded-md shadow-sm appearance-none focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 hover:bg-green-700"
            >
              Sign Up
            </button>
          </div>
        </form>

        <p className="mt-4 text-center text-sm text-gray-600">
            Already have an account?{' '}
            <button type="button" onClick={onCancel} className="font-medium text-green-600 hover:underline">
                Sign In
            </button>
        </p>
      </div>
    </div>
  );
};

export default EngineerSignUp;