
import React, { useRef, useEffect, useState } from 'react';
import { User } from '../types';

interface EngineerMapViewProps {
  engineers: User[];
}

const EngineerMapView: React.FC<EngineerMapViewProps> = ({ engineers }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  // Fix: Replaced specific Google Maps type with 'any' to resolve "Cannot find namespace 'google'" error.
  const mapInstance = useRef<any | null>(null);
  // Fix: Replaced specific Google Maps type with 'any' to resolve "Cannot find namespace 'google'" error.
  const markersRef = useRef<any[]>([]);
  // Fix: Replaced specific Google Maps type with 'any' to resolve "Cannot find namespace 'google'" error.
  const infoWindowRef = useRef<any | null>(null);

  const [isLoadingMap, setIsLoadingMap] = useState(true);
  const [mapError, setMapError] = useState<string | null>(null);

  useEffect(() => {
    // Fix: Cast 'window' to 'any' to resolve "Property 'google' does not exist on type 'Window & typeof globalThis'" error.
    if (!(window as any).google || !(window as any).google.maps) {
      console.warn("Google Maps API not loaded. Ensure 'YOUR_API_KEY_HERE' in index.html is replaced with a valid key and the script loaded successfully.");
      setMapError("Map services are unavailable. Please check your Google Maps API key and internet connection.");
      setIsLoadingMap(false);
      return;
    }
    setMapError(null); // Clear any previous errors

    const initializeMap = () => {
      if (mapRef.current && !mapInstance.current) {
        const defaultLatLng = { lat: 0, lng: 0 }; // Default center if no engineers
        // Fix: Replaced specific Google Maps type with 'any' and cast 'window' to 'any'.
        const mapOptions: any = {
          center: defaultLatLng,
          zoom: 2, // World view zoom
          mapId: 'YOUR_MAP_ID', // Optional: Use a Cloud-based map style ID if available
        };
        // Fix: Cast 'window' to 'any' to resolve "Property 'google' does not exist on type 'Window & typeof globalThis'" error.
        mapInstance.current = new (window as any).google.maps.Map(mapRef.current, mapOptions);
        // Fix: Cast 'window' to 'any' to resolve "Property 'google' does not exist on type 'Window & typeof globalThis'" error.
        infoWindowRef.current = new (window as any).google.maps.InfoWindow();
        setIsLoadingMap(false);
      }
    };

    // If initMap from index.html already ran, initialize immediately.
    // Otherwise, it might be async, or mapInstance.current is already set.
    if (mapRef.current) {
        initializeMap();
    }
  }, []);

  useEffect(() => {
    // Fix: Cast 'window' to 'any' to resolve "Property 'google' does not exist on type 'Window & typeof globalThis'" error.
    if (!mapInstance.current || !(window as any).google || !(window as any).google.maps) {
      return;
    }

    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];

    let hasLocations = false;

    // Fix: Cast 'window' to 'any' to resolve "Property 'google' does not exist on type 'Window & typeof globalThis'" error.
    const bounds = new (window as any).google.maps.LatLngBounds();
    

    engineers.forEach(engineer => {
      if (engineer.location) {
        hasLocations = true;
        const position = { lat: engineer.location.lat, lng: engineer.location.lng };
        // Fix: Cast 'window' to 'any' to resolve "Property 'google' does not exist on type 'Window & typeof globalThis'" error.
        const marker = new (window as any).google.maps.Marker({
          position,
          map: mapInstance.current,
          title: engineer.name,
          // You could customize icons here based on online status, etc.
        });

        marker.addListener('click', () => {
          if (infoWindowRef.current) {
            infoWindowRef.current.setContent(`<div><strong>${engineer.name}</strong><br/>Status: ${engineer.isOnline ? 'Online' : 'Offline'}</div>`);
            infoWindowRef.current.open(mapInstance.current, marker);
          }
        });
        markersRef.current.push(marker);
        bounds.extend(position);
      }
    });

    if (hasLocations) {
      mapInstance.current.fitBounds(bounds);
      // Optional: Set a minimum zoom level after fitting bounds
      if (mapInstance.current.getZoom() > 15) {
        mapInstance.current.setZoom(15);
      }
    } else {
      // Reset to a default wider view if no engineers have locations
      mapInstance.current.setCenter({ lat: 0, lng: 0 });
      mapInstance.current.setZoom(2);
    }
  }, [engineers]); // Re-run effect when the engineers prop changes

  return (
    <div className="flex flex-col h-full bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Engineer Locations (Live)</h3>
      {isLoadingMap && (
        <div className="flex items-center justify-center h-full text-gray-500">
          Loading Map...
        </div>
      )}
      {mapError && (
        <div className="flex items-center justify-center h-full text-red-600 bg-red-50 p-4 rounded-md">
          {mapError}
        </div>
      )}
      <div ref={mapRef} className="flex-1 rounded-md overflow-hidden" style={{ minHeight: '400px' }}>
        {/* Map will be rendered here */}
      </div>
       <p className="text-xs text-gray-500 mt-2">
        Note: Only active and online engineers with shared locations are shown. Ensure your Google Maps API key is valid.
      </p>
    </div>
  );
};

export default EngineerMapView;
    