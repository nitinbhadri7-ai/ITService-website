import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { InfinityIcon } from './icons/InfinityIcon';
import { MailIcon } from './icons/MailIcon';
import { LockIcon } from './icons/LockIcon';
import { InfoIcon } from './icons/InfoIcon';

interface LoginProps {
  onLogin: (user: User, role: UserRole) => void;
  users: User[];
  onShowSignUp: () => void; // New prop to signal showing sign-up form
}

const Login: React.FC<LoginProps> = ({ onLogin, users, onShowSignUp }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loginRole, setLoginRole] = useState<UserRole>('engineer'); // Default to engineer login

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); // Clear previous errors

    const user = users.find(u => u.email === email);

    if (!user) {
      setError('Invalid email or password.');
      return;
    }

    // In a real app, you'd verify the password hash.
    // For this demo, any password works if the user exists.

    if (user.role !== loginRole) {
      setError(`Access Denied: You are a ${user.role}. Please use the ${user.role} panel.`);
      return;
    }

    if (user.status === 'pending') {
      setError('Your account is pending admin approval.');
      return;
    }

    if (user.status === 'active') {
      onLogin(user, loginRole); // Pass the intended login role
    } else {
      setError('Your account is not active. Please contact an administrator.');
    }
  };

  const adminButtonClass = loginRole === 'admin' ? 'bg-blue-600 text-white' : 'bg-white text-blue-600 border border-blue-600';
  const engineerButtonClass = loginRole === 'engineer' ? 'bg-green-600 text-white' : 'bg-white text-green-600 border border-green-600';
  const signInButtonClass = loginRole === 'admin' ? 'bg-blue-600 hover:bg-blue-700 focus:ring-blue-500' : 'bg-green-600 hover:bg-green-700 focus:ring-green-500';
  const infoBoxColor = loginRole === 'admin' ? 'bg-blue-50' : 'bg-green-50';
  const infoBoxTextColor = loginRole === 'admin' ? 'text-blue-600' : 'text-green-600';
  const adminInfoTextColor = loginRole === 'admin' ? 'text-blue-700' : 'text-gray-600';


  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <div className="flex flex-col items-center">
            <div className="bg-gray-800 p-3 rounded-xl flex flex-col items-center">
                <InfinityIcon className="w-12 h-12 text-white"/>
                <h1 className="mt-2 text-xl font-bold text-white">ITCL</h1>
                <p className="text-sm font-light text-white">FRATERNITY</p>
            </div>
            <h2 className="mt-6 text-2xl font-bold text-center text-gray-900">
                ITCL FRATERNITY
            </h2>
            <p className="mt-2 text-base text-center text-gray-600">
                Sign in to continue
            </p>
        </div>

        {/* Role Selection Tabs */}
        <div className="flex justify-center space-x-4 mb-6">
            <button
                type="button"
                className={`flex-1 py-2 px-4 rounded-lg font-medium transition-colors duration-200 ${adminButtonClass}`}
                onClick={() => setLoginRole('admin')}
            >
                Admin
            </button>
            <button
                type="button"
                className={`flex-1 py-2 px-4 rounded-lg font-medium transition-colors duration-200 ${engineerButtonClass}`}
                onClick={() => setLoginRole('engineer')}
            >
                Engineer
            </button>
        </div>

        <form className="space-y-6" onSubmit={handleSubmit}>
          <div>
            <label htmlFor="email" className="text-sm font-medium text-gray-700 sr-only">
              Email address
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <MailIcon className="w-5 h-5 text-gray-400" />
              </span>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full py-3 pl-10 pr-3 border border-gray-300 rounded-md shadow-sm appearance-none placeholder:text-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                placeholder="Email"
              />
            </div>
          </div>

          <div>
            <label htmlFor="password" className="text-sm font-medium text-gray-700 sr-only">
              Password
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <LockIcon className="w-5 h-5 text-gray-400" />
              </span>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full py-3 pl-10 pr-3 border border-gray-300 rounded-md shadow-sm appearance-none placeholder:text-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                placeholder="Password"
              />
            </div>
          </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                {/* Remember Me toggle (functional only visually) */}
                <button
                    type="button"
                    role="switch"
                    aria-checked="false" // Always false as it's not truly functional
                    className={`relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-${loginRole === 'admin' ? 'blue' : 'green'}-500 ${loginRole === 'admin' ? 'bg-blue-600' : 'bg-green-600'}`}
                >
                    <span
                        aria-hidden="true"
                        className="pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200 translate-x-5"
                    ></span>
                </button>
                <span className="ml-3 text-sm text-gray-900">Remember me</span>
              </div>
            </div>

          {error && (
            <div className="flex items-start p-3 text-sm text-red-700 bg-red-100 rounded-md">
              <InfoIcon className="w-5 h-5 mr-2 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <button
              type="submit"
              className={`flex justify-center w-full px-4 py-3 text-sm font-medium text-white border border-transparent rounded-md shadow-sm appearance-none focus:outline-none focus:ring-2 focus:ring-offset-2 ${signInButtonClass}`}
            >
              Sign In
            </button>
          </div>
        </form>
        {loginRole === 'admin' && (
            <div className={`flex items-start p-4 text-sm ${adminInfoTextColor} ${infoBoxColor} rounded-md`}>
                <InfoIcon className={`w-5 h-5 mr-2 ${loginRole === 'admin' ? 'text-blue-500' : 'text-green-500'}`} />
                <span>Admin accounts must be created in Firebase Authentication Console</span>
            </div>
        )}
        {loginRole === 'engineer' && (
            <p className="mt-4 text-center text-sm text-gray-600">
                Don't have an account?{' '}
                <button type="button" onClick={onShowSignUp} className={`font-medium ${infoBoxTextColor} hover:underline`}>
                    Sign Up
                </button>
            </p>
        )}
      </div>
    </div>
  );
};

export default Login;