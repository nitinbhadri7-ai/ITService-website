import React, { useState, useRef } from 'react';
import { UserIcon } from './icons/UserIcon';
import { CameraIcon } from './icons/CameraIcon';
import { User } from '../types';

interface ProfileViewProps {
  currentUser: User;
  onUpdateUser: (user: User) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ currentUser, onUpdateUser }) => {
    const [name, setName] = useState(currentUser.name);
    const [phone, setPhone] = useState('+91 12345 67890'); // Mock phone
    const email = currentUser.email; // Email is not editable
    const [selfie, setSelfie] = useState<string | null>(null); // Placeholder for selfie URL
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                setSelfie(e.target?.result as string);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleSaveChanges = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would typically send the data to your backend
        console.log('Saving profile:', { name, phone, selfie: selfie ? 'Image data...' : 'No image' });
        // In a real app, update currentUser on backend and then call onUpdateUser with new data
        const updatedUser = { ...currentUser, name, //phone: phone if you stored phone on user object
        };
        onUpdateUser(updatedUser); // Update name in central state
        alert('Profile saved successfully!');
    };

    const handleToggleOnlineStatus = () => {
      const updatedUser = { ...currentUser, isOnline: !currentUser.isOnline };
      onUpdateUser(updatedUser);
    };

    return (
        <div className="bg-white rounded-lg shadow p-6 max-w-2xl mx-auto">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Edit Profile</h3>
            <form onSubmit={handleSaveChanges}>
                <div className="flex items-center space-x-6 mb-8">
                    <div className="relative">
                         {selfie ? (
                            <img src={selfie} alt="Selfie" className="h-24 w-24 rounded-full object-cover" />
                        ) : (
                            <div className="h-24 w-24 rounded-full bg-gray-200 flex items-center justify-center">
                                <UserIcon className="h-12 w-12 text-gray-400" />
                            </div>
                        )}
                        <button
                            type="button"
                            onClick={handleUploadClick}
                            className="absolute bottom-0 right-0 bg-green-600 text-white rounded-full p-2 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                        >
                            <CameraIcon className="h-5 w-5" />
                        </button>
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileChange}
                            className="hidden"
                            accept="image/*"
                            capture="user" // This prompts for camera on mobile
                        />
                    </div>
                    <div>
                        <h4 className="text-xl font-bold text-gray-800">{name}</h4>
                        <p className="text-gray-500">{email}</p>
                    </div>
                </div>

                <div className="space-y-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
                        <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                        />
                    </div>
                     <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone Number</label>
                        <input
                            type="tel"
                            id="phone"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                        />
                    </div>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            readOnly
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-gray-100 text-gray-500 sm:text-sm"
                        />
                    </div>
                    <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">Online Status</span>
                        <button
                            type="button"
                            onClick={handleToggleOnlineStatus}
                            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 ${
                                currentUser.isOnline ? 'bg-green-600' : 'bg-gray-200'
                            }`}
                            aria-label={currentUser.isOnline ? 'Mark as offline' : 'Mark as online'}
                        >
                            <span
                                className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${
                                    currentUser.isOnline ? 'translate-x-6' : 'translate-x-1'
                                }`}
                            />
                        </button>
                    </div>
                </div>
                 <div className="mt-8 flex justify-end">
                    <button
                        type="submit"
                        className="px-6 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                    >
                        Save Changes
                    </button>
                </div>
            </form>
        </div>
    );
};