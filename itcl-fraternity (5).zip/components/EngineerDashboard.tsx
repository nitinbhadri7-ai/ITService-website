import React, { useState } from 'react';
import { UserIcon } from './icons/UserIcon';
import { BellIcon } from './icons/BellIcon';
import { ClipboardListIcon } from './icons/ClipboardListIcon';
import { InfinityIcon } from './icons/InfinityIcon';
import { ProfileView } from './ProfileView';
import { AlertTriangleIcon } from './icons/AlertTriangleIcon';
import { PlusIcon } from './icons/PlusIcon'; // New icon
import { Ticket, User, EmergencyAlert, TicketStatus, Priority } from '../types';
import { CheckIcon } from './icons/CheckIcon'; // Import CheckIcon for save button
import { MapPinIcon } from './icons/MapPinIcon'; // Import MapPinIcon

interface EngineerDashboardProps {
  onLogout: () => void;
  tickets: Ticket[];
  myAlerts: EmergencyAlert[]; // New prop for engineers to view their own alerts
  currentUser: User;
  onUpdateUser: (user: User) => void;
  onCreateEmergencyAlert: (engineerId: number, note: string, location: { lat: number; lng: number }) => void;
  onCreateTicket: (customerName: string, customerPhone: string, customerAddress: string, issue: string, priority: Priority, notes?: string) => void;
  onAlertsUpdate: (alerts: EmergencyAlert[]) => void; // For resolving alerts
  onUpdateTicket: (updatedTicket: Ticket) => void; // New prop for updating tickets
}

const EngineerDashboard: React.FC<EngineerDashboardProps> = ({ onLogout, tickets, myAlerts, currentUser, onUpdateUser, onCreateEmergencyAlert, onCreateTicket, onAlertsUpdate, onUpdateTicket }) => {
  const [activeTab, setActiveTab] = useState<'tickets' | 'profile' | 'myalerts'>('tickets');
  const [isCreateCallModalOpen, setCreateCallModalOpen] = useState(false);
  const [isEmergencyAlertModalOpen, setEmergencyAlertModalOpen] = useState(false);
  const [isAlertDetailsModalOpen, setAlertDetailsModalOpen] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState<EmergencyAlert | null>(null);

  // States for engineer ticket details modal
  const [isTicketDetailsModalOpen, setTicketDetailsModalOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [editedStatus, setEditedStatus] = useState<TicketStatus | ''>('');
  const [editedNotes, setEditedNotes] = useState<string>('');

  // State for location sharing
  const [isSharingLocation, setIsSharingLocation] = useState(false);


  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open': return 'bg-red-100 text-red-800';
      case 'In Progress': return 'bg-yellow-100 text-yellow-800';
      case 'Resolved': return 'bg-green-100 text-green-800';
      case 'Cancelled': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleCreateCall = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const customerName = formData.get('customerName') as string;
    const customerPhone = formData.get('customerPhone') as string;
    const customerAddress = formData.get('customerAddress') as string;
    const issue = formData.get('issue') as string;
    const priority = formData.get('priority') as Priority;
    const notes = formData.get('notes') as string;

    onCreateTicket(customerName, customerPhone, customerAddress, issue, priority, notes);
    setCreateCallModalOpen(false);
    alert('New call created and assigned to you!');
  };

  const handleSendEmergencyAlert = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const note = formData.get('note') as string;

    if (!currentUser.location) {
        alert('Cannot send emergency alert: Your location is not available.');
        return;
    }
    onCreateEmergencyAlert(currentUser.id, note, currentUser.location);
    setEmergencyAlertModalOpen(false);
    alert('Emergency alert sent to admins!');
  };

  const handleShareLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setIsSharingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const updatedUser = { ...currentUser, location: { lat: latitude, lng: longitude } };
        onUpdateUser(updatedUser);
        setIsSharingLocation(false);
        alert('Location shared successfully!');
      },
      (error) => {
        console.error('Geolocation error:', error);
        setIsSharingLocation(false);
        let errorMessage = 'Failed to get location.';
        if (error.code === error.PERMISSION_DENIED) {
          errorMessage = 'Location access denied. Please enable location services for this site.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          errorMessage = 'Location information is unavailable.';
        } else if (error.code === error.TIMEOUT) {
          errorMessage = 'The request to get user location timed out.';
        }
        alert(errorMessage);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 } // Options for getCurrentPosition
    );
  };

  const handleResolveAlert = (alertId: number) => {
    onAlertsUpdate(myAlerts.map(a => a.id === alertId ? { ...a, status: 'resolved' } : a));
    setAlertDetailsModalOpen(false);
  };

  // New functions for engineer ticket management
  const handleOpenTicketDetails = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setEditedStatus(ticket.status);
    setEditedNotes(ticket.notes || '');
    setTicketDetailsModalOpen(true);
  };

  const handleSaveTicketChanges = () => {
    if (selectedTicket && editedStatus) {
      // Validation for mandatory notes on 'Resolved' or 'Cancelled' status
      if ((editedStatus === 'Resolved' || editedStatus === 'Cancelled') && editedNotes.trim() === '') {
        alert('Notes are mandatory when resolving or cancelling a ticket.');
        return;
      }

      const updatedTicket: Ticket = {
        ...selectedTicket,
        status: editedStatus,
        notes: editedNotes.trim() === '' ? undefined : editedNotes,
      };
      onUpdateTicket(updatedTicket); // Use the prop to update the ticket
      setSelectedTicket(updatedTicket); // Update local selectedTicket for display
      setTicketDetailsModalOpen(false);
      alert('Ticket updated successfully!');
    }
  };

  const TicketsView = () => (
     <div className="bg-white rounded-lg shadow">
        <div className="p-4 border-b flex justify-between items-center">
            <h3 className="text-lg font-semibold">My Assigned Tickets</h3>
            <button onClick={() => setCreateCallModalOpen(true)} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 flex items-center">
                <PlusIcon className="w-4 h-4 mr-2" /> Create New Call
            </button>
        </div>
        <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
                <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ticket ID</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Issue</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th scope="col" className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                    </th>
                </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
                {tickets.map((ticket) => (
                    <tr key={ticket.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{ticket.id}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{ticket.customer.name}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-sm">{ticket.issue}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{ticket.priority}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(ticket.status)}`}>
                                {ticket.status}
                            </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button onClick={() => handleOpenTicketDetails(ticket)} className="text-indigo-600 hover:text-indigo-900">View/Update</button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
    </div>
  );

  const MyAlertsView = () => (
    <div className="bg-white rounded-lg shadow">
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                    <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Alert ID</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                    {myAlerts.map(alert => (
                        <tr key={alert.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{alert.id}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(alert.timestamp).toLocaleString()}</td>
                            <td className="px-6 py-4 text-sm text-gray-500 truncate max-w-md">{alert.note}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${alert.status === 'active' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                                    {alert.status}
                                </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <button onClick={() => { setSelectedAlert(alert); setAlertDetailsModalOpen(true); }} className="text-indigo-600 hover:text-indigo-900">View Details</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-gray-800 text-white flex flex-col">
        <div className="flex items-center justify-center h-20 border-b border-gray-700">
            <InfinityIcon className="h-8 w-8 mr-2" />
            <h1 className="text-xl font-bold">ITCL Engineer</h1>
        </div>
        <nav className="flex-1 px-4 py-6 space-y-2">
          <button 
            onClick={() => setActiveTab('tickets')}
            className={`flex items-center w-full px-4 py-2 text-left rounded-md transition-colors ${activeTab === 'tickets' ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}
          >
            <ClipboardListIcon className="h-5 w-5 mr-3" />
            My Tickets
          </button>
          <button 
            onClick={() => setActiveTab('profile')}
            className={`flex items-center w-full px-4 py-2 text-left rounded-md transition-colors ${activeTab === 'profile' ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}
          >
            <UserIcon className="h-5 w-5 mr-3" />
            Profile
          </button>
          <button 
            onClick={() => setActiveTab('myalerts')}
            className={`flex items-center w-full px-4 py-2 text-left rounded-md transition-colors ${activeTab === 'myalerts' ? 'bg-gray-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}`}
          >
            <AlertTriangleIcon className="h-5 w-5 mr-3" />
            My Alerts
          </button>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="flex justify-between items-center p-6 bg-white border-b">
          <h2 className="text-2xl font-semibold text-gray-800">
            {activeTab === 'tickets' ? 'My Tickets' : activeTab === 'profile' ? 'My Profile' : 'My Emergency Alerts'}
          </h2>
          <div className="flex items-center space-x-4">
            {currentUser.isOnline ? (
                <span className="inline-flex items-center px-3 py-1 text-sm font-medium leading-4 text-green-800 bg-green-100 rounded-full">
                    Online
                </span>
            ) : (
                <span className="inline-flex items-center px-3 py-1 text-sm font-medium leading-4 text-gray-800 bg-gray-100 rounded-full">
                    Offline
                </span>
            )}
            <button
                onClick={handleShareLocation}
                disabled={isSharingLocation}
                className={`px-4 py-2 text-sm font-medium text-white rounded-md ${isSharingLocation ? 'bg-gray-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700'} focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 flex items-center`}
            >
                <MapPinIcon className="w-4 h-4 mr-2" /> {isSharingLocation ? 'Getting Location...' : 'Share My Location'}
            </button>
            <button
                onClick={() => setEmergencyAlertModalOpen(true)}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
                SEND EMERGENCY ALERT
            </button>
            <BellIcon className="h-6 w-6 text-gray-500" />
            <div className="flex items-center space-x-2">
                <UserIcon className="h-8 w-8 text-gray-500 rounded-full bg-gray-200 p-1" />
                <div>
                    <div className="font-semibold">{currentUser.name}</div>
                    <div className="text-sm text-gray-500 capitalize">{currentUser.role}</div>
                </div>
            </div>
            <button
              onClick={onLogout}
              className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
            >
              Logout
            </button>
          </div>
        </header>

        {/* Content area */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
            {activeTab === 'tickets' && <TicketsView />}
            {activeTab === 'profile' && <ProfileView currentUser={currentUser} onUpdateUser={onUpdateUser} />}
            {activeTab === 'myalerts' && <MyAlertsView />}
        </main>
      </div>

      {/* Create Call Modal */}
      {isCreateCallModalOpen && (
             <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={() => setCreateCallModalOpen(false)}>
                <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
                    <h3 className="text-lg font-bold mb-4">Create New Call/Delivery</h3>
                    <form onSubmit={handleCreateCall}>
                        <div className="space-y-4">
                            <input name="customerName" placeholder="Customer Name" required className="w-full p-2 border rounded"/>
                            <input name="customerPhone" placeholder="Customer Phone" required className="w-full p-2 border rounded"/>
                            <input name="customerAddress" placeholder="Customer Address" required className="w-full p-2 border rounded"/>
                            <textarea name="issue" placeholder="Item/Issues" required className="w-full p-2 border rounded"></textarea>
                            <select name="priority" defaultValue="Medium" className="w-full p-2 border rounded">
                                <option>Low</option>
                                <option>Medium</option>
                                <option>High</option>
                                <option>Critical</option>
                            </select>
                            <textarea name="notes" placeholder="Notes (optional)" className="w-full p-2 border rounded"></textarea>
                        </div>
                        <div className="mt-6 flex justify-end space-x-4">
                            <button type="button" onClick={() => setCreateCallModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                            <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded">Create Call</button>
                        </div>
                    </form>
                </div>
            </div>
        )}

      {/* Emergency Alert Modal (Engineer initiates) */}
      {isEmergencyAlertModalOpen && (
             <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={() => setEmergencyAlertModalOpen(false)}>
                <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
                    <h3 className="text-lg font-bold mb-4 text-red-600">Send Emergency Alert</h3>
                    <p className="text-sm text-gray-700 mb-4">Your current location will be sent to administrators.</p>
                    <form onSubmit={handleSendEmergencyAlert}>
                        <div className="space-y-4">
                            <textarea name="note" placeholder="Brief description of the emergency..." required rows={4} className="w-full p-2 border rounded"></textarea>
                            {currentUser.location && (
                                <p className="text-xs text-gray-500">Location: Lat {currentUser.location.lat.toFixed(4)}, Lng {currentUser.location.lng.toFixed(4)}</p>
                            )}
                            {!currentUser.location && (
                                <p className="text-xs text-red-500">Warning: Location not available. Alert will be sent without coordinates.</p>
                            )}
                        </div>
                        <div className="mt-6 flex justify-end space-x-4">
                            <button type="button" onClick={() => setEmergencyAlertModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                            <button type="submit" className="px-4 py-2 bg-red-600 text-white rounded">Send Alert</button>
                        </div>
                    </form>
                </div>
            </div>
        )}

        {/* Engineer Alert Details Modal (for engineer to view their own alerts) */}
        {isAlertDetailsModalOpen && selectedAlert && (
            <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={() => setAlertDetailsModalOpen(false)}>
                <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
                    <h3 className="text-lg font-bold mb-4 text-red-600">My Emergency Alert Details</h3>
                    <p><strong>Time:</strong> {new Date(selectedAlert.timestamp).toLocaleString()}</p>
                    <p><strong>Note:</strong> {selectedAlert.note}</p>
                    <p><strong>Location:</strong> Lat {selectedAlert.location.lat}, Lng {selectedAlert.location.lng}</p>
                    <p><strong>Status:</strong> {selectedAlert.status === 'active' ? 'Active' : 'Resolved'}</p>
                    <div className="mt-6 flex justify-end">
                        <button onClick={() => setAlertDetailsModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Close</button>
                    </div>
                </div>
            </div>
        )}

        {/* Engineer Ticket Details Modal */}
        {isTicketDetailsModalOpen && selectedTicket && (
            <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center" onClick={() => setTicketDetailsModalOpen(false)}>
                <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg" onClick={e => e.stopPropagation()}>
                    <h3 className="text-lg font-bold mb-4">Ticket Details - #{selectedTicket.id}</h3>
                    <p><strong>Issue:</strong> {selectedTicket.issue}</p>
                    <p><strong>Priority:</strong> {selectedTicket.priority}</p>
                    <p className="flex items-center">
                        <strong>Status:</strong>
                        <select
                            value={editedStatus}
                            onChange={(e) => setEditedStatus(e.target.value as TicketStatus)}
                            className="ml-2 p-1 border rounded text-sm"
                            disabled={selectedTicket.status === 'Resolved' || selectedTicket.status === 'Cancelled'} // Disable if already resolved/cancelled
                        >
                            <option value="Open">Open</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Resolved">Resolved</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </p>
                    <p><strong>Customer:</strong> {selectedTicket.customer.name}</p>
                    <p><strong>Customer Phone:</strong> {selectedTicket.customer.phone}</p>
                    <p><strong>Customer Address:</strong> {selectedTicket.customer.address}</p>
                    <p>
                        <strong>Assigned To:</strong>
                        <span className="ml-2">{currentUser.name} (You)</span>
                    </p>
                    <p><strong>Created By:</strong> {currentUser.name}</p>
                    <p><strong>Created At:</strong> {new Date(selectedTicket.createdAt).toLocaleString()}</p>
                    <div className="mt-4">
                        <strong>Notes:</strong>
                        <textarea
                            value={editedNotes}
                            onChange={(e) => setEditedNotes(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                            rows={3}
                            placeholder="Add notes for this ticket"
                        ></textarea>
                        {(editedStatus === 'Resolved' || editedStatus === 'Cancelled') && editedNotes.trim() === '' && (
                            <p className="text-red-500 text-xs mt-1">Notes are mandatory for Resolved/Cancelled tickets.</p>
                        )}
                    </div>

                    <div className="mt-6 flex justify-end space-x-2">
                        <button onClick={() => setTicketDetailsModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Close</button>
                        <button
                            onClick={handleSaveTicketChanges}
                            className={`px-4 py-2 text-white rounded-md ${
                                (editedStatus === 'Resolved' || editedStatus === 'Cancelled') && editedNotes.trim() === ''
                                    ? 'bg-gray-400 cursor-not-allowed'
                                    : 'bg-green-600 hover:bg-green-700'
                            } flex items-center`}
                            disabled={(editedStatus === 'Resolved' || editedStatus === 'Cancelled') && editedNotes.trim() === ''}
                        >
                            <CheckIcon className="w-4 h-4 mr-2"/> Save Changes
                        </button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default EngineerDashboard;